# 订单与多条售后关联：合成案例

全部记录为自制演示，不是真实店铺或客户资料。
先解压，再用浏览器打开 result/report.html，无需安装程序或联网。
本包只有源数据与实际结果，不含处理程序，不能处理你自己的文件。

输入：orders.csv 有7条订单记录；after_sales.csv 有10条售后记录。
结果：3个唯一订单关联4条售后，1条订单无售后，1条售后找不到订单，
另有3条订单记录与5条售后记录待复核。物理行号包括首行表头。

结果文件：
- report.html：分类摘要、预览、原因与来源行号。
- report.json：完整原始字段、规则、源文件哈希和记录位置。
- associations.csv：4条关联；order_sources.csv：对应的订单来源。
- orders_without_after_sales.csv：1条无对应售后订单，不代表异常。
- after_sales_without_orders.csv：1条找不到订单的售后，待核。
- review_rows.csv：8条待复核记录，按每行原因处理。

导入CSV时，将编号列设为文本，避免表格软件改写前导零或长整数。
金额只保留原文；本例不比较或汇总金额，不判断退款完成和财务结果。
左订单键不唯一、右侧完全重复行会待核，不以猜配或静默删除处理。
记录全部归类不是完成对账；还需要核对真实业务规则和导出范围。

实操解释：https://www.laoliu.me/order-after-sale-matching/
可选需求说明：https://www.laoliu.me/assist/?service=data&source=blog
